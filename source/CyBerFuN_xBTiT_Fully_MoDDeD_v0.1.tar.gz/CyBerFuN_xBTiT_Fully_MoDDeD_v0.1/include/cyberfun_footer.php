<?php
$cyberfun_footer="[&nbsp;&nbsp;<u>CyBerFuN xBTiT By cybernet</u>: <a href=\"http://tracker.cyberfun.ro/\" target=\"_blank\">CyBerFuN Tracker</a>&nbsp;]
[&nbsp;&nbsp;<u>xbtit '.$tracker_version.' By</u>: <a href=\"http://www.btiteam.org/\" target=\"_blank\">Btiteam</a>&nbsp;]";
?>
