function nav()
{
    document.write('<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"  width="454" height="57"  ...>\n');
    document.write('<param name="movie" value="styles/XNeon/images/xneonheadernav.swf" />\n');
	document.write('<param name="BGCOLOR" value="#000000" />\n');
	document.write('<embed src="styles/XNeon/images/xneonheadernav.swf" pluginspage="http://www.macromedia.com/shockwave/download/" width="454" height="57"></embed>');
    document.write('</object>\n');
}
function forumhead()
{
    document.write('<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"  width="600" height="100"  ...>\n');
    document.write('<param name="movie" value="styles/XNeon/images/forumhead.swf" />\n');
	document.write('<param name="BGCOLOR" value="#000000" />\n');
	document.write('<embed src="styles/XNeon/images/forumhead.swf" pluginspage="http://www.macromedia.com/shockwave/download/" width="600" height="100"></embed>');
    document.write('</object>\n');
}

