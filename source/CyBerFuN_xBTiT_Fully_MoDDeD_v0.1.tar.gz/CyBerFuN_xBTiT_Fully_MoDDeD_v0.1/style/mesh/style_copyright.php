<?php
$design_copyright='<a href="http://cyberfun.ro" target="_blank">CyBerFuN</a>';
?>
