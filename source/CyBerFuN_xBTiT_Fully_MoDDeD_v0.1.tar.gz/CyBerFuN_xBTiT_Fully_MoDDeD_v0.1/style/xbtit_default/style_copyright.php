<?php
$design_copyright='<a href="http://global-bttracker.no-ip.org/forum/" target="_blank">TreetopClimber</a>';
?>