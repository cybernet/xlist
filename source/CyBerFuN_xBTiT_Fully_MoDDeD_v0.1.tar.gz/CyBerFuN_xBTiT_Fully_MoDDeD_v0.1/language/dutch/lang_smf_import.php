<?php

// smf_import.php language file

$lang[0]="Ja";
$lang[1]="Nee";
$lang[2]="<center><u><strong><font size='4' face='Arial'>Fase 1: Belangrijke Vereisten</font></strong></u></center><br />";
$lang[3]="<center><strong><font face='Arial' size='2'>SMF bestanden aanwezig in de \"smf\" map?<font color='";
$lang[4]="'>&nbsp;&nbsp;&nbsp; ";
$lang[5]="</font></center></strong>";
$lang[6]="<br /><center>Download aub <a target='_new' href='http://www.simplemachines.org/download/'>SMF</a> en upload de inhoud van het bestand naar de \"smf\" map.<br />Als u geen \"smf\" map heeft maak er dan aub een aan en upload<br />de inhoud van het bestand naar die map.<br /><br />Eenmaal geupload installeer a";
$lang[7]="<br /><center>Installeer a";
$lang[8]="ub SMF door <a target='_new' href='smf/install.php'>hier</a> te klikken*<br /><br /><strong>* Gebruik aub dezelfde database gegevens als dat van uw tracker,<br />u kunt elk voorvoegsel voor uw database gebruiken (behalve degene die u gebruikt<br />heeft voor uw tracker)<br /><br />";
$lang[9]="<font color='#0000FF' size='3'>U moet misschien deze pagina vernieuwen wanneer u de taak voltooid heeft!</font></strong></center>";
$lang[10]="<center><strong>SMF ge&iuml;nstalleerd?<font color='";
$lang[11]="Bestand niet gevonden!";
$lang[12]="Bestand gevonden, maar niet schrijfbaar!";
$lang[13]="<center><strong>Standaard SMF Engels Fouten bestand beschikbaar en schrijfbaar?<font color='";
$lang[14]="<center><strong>smf.sql bestand aanwezig in de \"sql\" map?<font color='";
$lang[15]="<br /><center><strong>Taalbestand (";
$lang[16]=")<br />is missend, zorg er aub voor dat u<font color='#FF0000'><u>alle SMF bestanden</u></font> heeft geupload!<br /><br />";
$lang[17]=")<br />is niet schrijfbaar, <font color='#FF0000'><u>CHMOD dit bestand naar 777 aub</u></font><br /><br />";
$lang[18]="<br /><center><strong>smf.sql is missend, <font color='#FF0000'><u>zorg ervoor dat dit bestand aanwezig is in de \"sql\" map.</u></font><br />(Het zou er standaard bij moeten zitten bij een XBTIT pakket!)<br /><br />";
$lang[19]="<br /><center>Alle vereisten zijn behandeld, klik <a href='";
$lang[20]="'>hier aub om verder te gaan</a></center>";
$lang[21]="<center><u><strong><font size='4' face='Arial'>Fase 2: Vereiste Instellingen</font></strong></u></center><br />";
$lang[22]="<center>Nu dat we zeker weten dat alles er is zoals het hoort te zijn<br />is het tijd om de database te veranderen en alles in order te maken voor de tracker.</center><br />";
$lang[23]="<center><strong>klik aub<a href='".$_SERVER["PHP_SELF"]."?act=init_setup&confirm=yes'>here</a> om verder te gaan</center>";
$lang[24]="<center><u><strong><font size='4' face='Arial'>Fase 3: Importeren van trackerleden</font></strong></u></center><br />";
$lang[25]="<center>Nu dat de database correct is ingesteld is het tijd om de tracker leden te importeren,<br />Dit kan nogal lang duren als u een groot aantal gebruiker heeft, dus wees geduldig<br />en laat het script zijn werk doen!<br /><br /><strong>klik aub <a href='".$_SERVER["PHP_SELF"]."?act=member_import&confirm=yes'>hier</a> om verder te gaan</center>";
$lang[26]="<center><u><strong><font size='4' face='Arial'>Sorry</font></strong></u></center><br />";
$lang[27]="<center>Sorry, dit is bedoelt voor eenmalig gebruik en omdat u het al eens gebruik heeft is dit bestand vergrendeld!</center>";
$lang[28]="<center><br /><strong><font color='#FF0000'><br />";
$lang[29]="</strong></font> Forum accounts zijn met succes aangemaakt, klik aub <a href='".$_SERVER["PHP_SELF"]."?act=import_forum&confirm=no'>hier</a> om verder te gaan</center>";
$lang[30]="<center><u><strong><font size='4' face='Arial'>Fase 4: Importeren van forum layout & posts</font></strong></u></center><br />";
$lang[31]="<center>Dit is de laatste fase van het forum, deze zal uw huidige BTI forum importeren naar SMF,<br />het zal worden ge&iuml;mporteerd naar een nieuwe categorie genaamd \"My BTI import\",<br />klik aub <a href='".$_SERVER["PHP_SELF"]."?act=import_forum&confirm=yes'>hier</a> om verder te gaan</center>";
$lang[32]="<center><u><strong><font size='4' face='Arial'>Importeren Voltooid</font></strong></u></center><br />";
$lang[33]="<center><font face='Arial' size=2><a target='_new' href='smf/index.php?action=login'>Log aub in op uw nieuwe SMF forum</a> om gebruik te maken van uw tracker details en<br />ga naar het <strong>Administratie Centrum</strong> selecteer dan <strong>Forum Onderhoud</strong> en draai de<br /><strong>Zoek en repareer fouten.</strong> gevolgd door <strong>Tel alle forums opnieuw<br /> en statistieken.</strong> om installatie af te ronden en forum compleet te maken etc.<br /><br /><strong><font color='#0000FF'>U heeft het SMF Forum ge&iuml;ntegreerd en is klaar voor gebruik!</font></strong></font></center>";
$lang[34]="<center><u><strong><font size=\"4\" face=\"Arial\" color=\"#FF0000\">FOUT!</font></strong></u></center><br />\n<br />\n<center><font face=\"Arial\" size=\"3\">U heeft het verkeerde wachtwoord ingevuld of u bent niet de eigenaar van deze tracker!<br />\nHiervoor hebben wij uw IP adres opgeslagen.</font></center>";
$lang[35]="</body>\n</html>\n";
?>