<?php

$language["MEMBER_NAME"]= "Mitgliedname";
$language["ACCOUNT_CREATED"]="Benutzer eingerichtet";
$language["USER_NAME"]="Benutzer";
$language["USER_PWD_AGAIN"]="Wiederhole Passwort";
$language["USER_PWD"]="Passwort";
$language["USER_STYLE"]="Aussehen";
$language["USER_LANGUE"]="Sprache";
$language["IMAGE_CODE"]="Bilder-Code";
$language["INSERT_USERNAME"]="Bitte Benutzernamen eingeben!";
$language["INSERT_PASSWORD"]="Bitte Passwort eingeben!";
$language["DIF_PASSWORDS"]="Die Passw�rter stimmen nicht �berein!";
$language["ERR_NO_EMAIL"]="Bitte g�ltige E-Mail eingeben";
$language["USER_EMAIL_AGAIN"]="Wiederhole E-Mail Adresse";
$language["ERR_NO_EMAIL_AGAIN"]="Wiederhole E-Mail Adresse";
$language["DIF_EMAIL"]="Die E-Mail Adressen stimmen nicht �berein!";
$language["SECURITY_CODE"]="Sicherheitscode";
# Password strength
$language["WEEK"]="Mies";
$language["MEDIUM"]="Schlecht";
$language["SAFE"]="Gut";
$language["STRONG"]="Sehr gut";

?>