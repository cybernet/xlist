<?php

// Translated to Vietnamese Language by VoTienSinh  & ThanhThanh for www.diemthuy.nl

// smf_import.php language file

$lang[0]="V&#226;ng";
$lang[1]="Kh&#244;ng";
$lang[2]="<center><u><strong><font size='4' face='Arial'>Giai &#273;o&#7841;n 1: nh&#7919;ng &#273;&#242;i quan tr&#7885;ng</font></strong></u></center><br />";
$lang[3]="<center><strong><font face='Arial' size='2'>T&#224;i li&#7879;u SMF c&#243; trong h&#7891; s&#417; \"smf\" ?<font color='";
$lang[4]="'>&nbsp;&nbsp;&nbsp; ";
$lang[5]="</font></center></strong>";
$lang[6]="<br /><center>Xin t&#7843;i xu&#7889;ng <a target='_new' href='http://www.simplemachines.org/download/'>download SMF</a> v&#224; &#273;&#432;a n&#7897;i dung v&#224;o trong t&#7853;p \"smf\".<br />n&#7871;u b&#7841;n kh&#244;ng c&#243;, xin l&#224;m t&#7853;p \"smf\" v&#224;o trong s&#432;&#7901;n c&#7911;a n&#417;i xu&#7845;t ph&#225;t c&#7911;a b&#7841;n v&#224; c&#224;i n&#7897;i dung c&#7911;a t&#224;i li&#7879;u v&#224;o trong <br />.<br /><br />sau khi t&#7843;i l&#234;n, c&#224;i &#273;&#7863;t a
$lang[7]="<br /><center>c&#224;i &#273;&#7863;t a";
$lang[8]="c&#224;i &#273;&#7863;t SMF qua <a target='_new' href='smf/install.php'>b&#7845;m &#7903; &#273;&#226;y</a>*<br /><br /><strong>* Xin s&#7917; d&#7909;ng &#273;&#250;ng d&#7917; li&#7879;u nh&#432; &#7903; n&#417;i xu&#7845;t ph&#225;t c&#7911;a b&#7841;n,<br />b&#7841;n c&#243; th&#7875; s&#7917; d&#7909;ng b&#7845;t c&#7913; t&#7915; ch&#7881; danh hi&#7879;u b&#7841;n mu&#7889;n (ngo&#7841;i tr&#7915; t&#7915; ch&#7881; danh hi&#7879;u &#273;&#227; s&#7917; d&#7909;ng t&#7841;i <br />n&#417;i xu&#7845;t ph&#225;t c&#7911;a b&#7841;n)<br /><br />";
$lang[9]="<font color='#0000FF' size='3'>B&#7841;n c&#243; th&#7875; ph&#7843;i l&#224;m l&#7841;i trang m&#7899;i sau khi &#273;&#227; l&#224;m xong!</font></strong></center>";
$lang[10]="<center><strong>&#273;&#227; c&#224;i &#273;&#7863;t SMF ?<font color='";
$lang[11]="kh&#244;ng t&#236;m th&#7845;y t&#224;i li&#7879;u!";
$lang[12]="t&#236;m th&#7845;y t&#224;i li&#7879;u nh&#432;ng kh&#244;ng vi&#7871;t ra &#273;&#432;&#7907;c!";
$lang[13]="<center><strong>Tr&#7909;c tr&#7863;c c&#417; b&#7843;n SMF ti&#7871;ng Anh, t&#224;i li&#7879;u c&#243; th&#7875; ki&#7871;m v&#224; vi&#7871;t &#273;&#432;&#7907;c?<font color='";
$lang[14]="<center><strong>t&#224;i li&#7879;u smf.sql &#273;&#227; c&#243; trong h&#7891; s&#417; \"sql\" ?<font color='";
$lang[15]="<br /><center><strong>t&#224;i li&#7879;u ng&#244;n ng&#7917; (";
$lang[16]=")<br />&#273;ang b&#7883; thi&#7871;u, xin coi l&#7841;i ch&#7855;c ch&#7855;n <font color='#FF0000'><u>t&#7845;t c&#7843; t&#224;i li&#7879;u SMF</u></font> &#273;&#227; &#273;&#432;&#7907;c t&#7843;i l&#234;n!<br /><br />";
$lang[17]=")<br />kh&#244;ng vi&#7871;t ra &#273;&#432;&#7907;c, <font color='#FF0000'><u>xin chuy&#7875;n t&#224;i li&#7879;u CHMOD n&#224;y &#273;&#7871;n 777</u></font><br /><br />";
$lang[18]="<br /><center><strong>smf.sql &#273;ang b&#7883; thi&#7871;u, <font color='#FF0000'><u>xin coi l&#7841;i ch&#7855;c ch&#7855;n t&#224;i li&#7879;u n&#224;y &#273;&#227; c&#243; trong h&#7891; s&#417; \"sql\".</u></font><br />(N&#243; th&#236; ph&#7843;i c&#243; s&#7859;n trong s&#7921; ph&#226;n ph&#225;t c&#7911;a XBTIT!)<br /><br />";
$lang[19]="<br /><center>T&#7845;t c&#7843; &#273;&#242;i h&#7887;i &#273;&#227; &#273;&#432;&#7907;c th&#244;ng qua, b&#7845;m <a href='";
$lang[20]="'>b&#7845;m &#7903; &#273;&#226;y &#273;&#7875; ti&#7871;p t&#7909;c</a></center>";
$lang[21]="<center><u><strong><font size='4' face='Arial'>Giai &#273;o&#7841;n 2: nh&#7919;ng &#273;i&#7873;u ch&#7881;nh c&#7847;n thi&#7871;t</font></strong></u></center><br />";
$lang[22]="<center>B&#226;y gi&#7901; ch&#250;ng ta bi&#7871;t ch&#7855;c ch&#7855;n l&#224; t&#7845;t c&#7843; &#273;&#227; &#273;&#432;&#7907;c c&#224;i &#273;&#7863;t theo nh&#432; &#273;&#242;i h&#7887;i<br />&#273;&#7871;n l&#250;c ch&#250;ng ta thay &#273;&#7893;i cho kho d&#7917; li&#7879;u v&#224; t&#7845;t c&#7843; l&#224;m ho&#224;n ch&#7881;nh cho n&#417;i xu&#7845;t ph&#225;t.</center><br />";
$lang[23]="<center><strong>xin b&#7845;m<a href='".$_SERVER["PHP_SELF"]."?act=init_setup&confirm=yes'>here</a> &#273;&#7875; ti&#7871;p t&#7909;c</center>";
$lang[24]="<center><u><strong><font size='4' face='Arial'>Giai &#273;o&#7841;n 3: Nh&#7853;p th&#224;nh vi&#234;n v&#224;o n&#417;i xu&#7845;t ph&#225;t</font></strong></u></center><br />";
$lang[25]="<center>Kho d&#7917; li&#7879;u &#273;&#227; &#273;&#432;&#7907;c &#273;i&#7873;u ch&#7881;nh &#273;&#250;ng b&#226;y gi&#7901; t&#7899;i phi&#234;n nh&#7853;p th&#224;nh vi&#234;n v&#224;o n&#417;i xu&#7845;t ph&#225;t (di&#7875;n &#273;&#224;n),<br />V&#7845;n &#273;&#7873; n&#224;y c&#7847;n c&#243; th&#7901;i gian n&#7871;u b&#7841;n c&#243; nhi&#7873;u th&#224;nh vi&#234;n, xin ki&#234;n nh&#7849;n ch&#7901;<br />&#273;&#7875; b&#7843;n vi&#7871;t t&#7921; l&#224;m vi&#7879;c!<br /><br /><strong>xin b&#7845;m <a href='".$_SERVER["PHP_SELF"]."?act=member_import&amp;confirm=yes'>click here</a> &#273;&#7875; ti&#7871;p t&#7909;c</center>";
$lang[26]="<center><u><strong><font size='4' face='Arial'>xin l&#7893;i</font></strong></u></center><br />";
$lang[27]="<center>Xin l&#7893;i, c&#225;i n&#224;y ch&#7881; s&#7917; d&#7909;ng 1 l&#7847;n v&#224; v&#236; b&#7841;n &#273;&#227; s&#7917; d&#7909;ng r&#7891;i cho n&#234;n t&#224;i li&#7879;u n&#224;y b&#7883; kh&#243;a !</center>";
$lang[28]="<center><br /><strong><font color='#FF0000'><br />";
$lang[29]="</strong></font> Tr&#432;&#417;ng m&#7909;c c&#7911;a di&#7875;n &#273;&#224;n &#273;&#227; &#273;&#432;&#7907;c th&#224;nh c&#244;ng, xin b&#7845;m <a href='".$_SERVER["PHP_SELF"]."?act=import_forum&amp;confirm=no'>click here</a>&#273;&#7875; ti&#7871;p t&#7909;c</center>";
$lang[30]="<center><u><strong><font size='4' face='Arial'> Giai &#273;o&#7841;n 4: Nh&#7853;p v&#224;o nh&#7919;ng c&#225;ch tr&#236;nh b&#224;y v&#224; b&#224;i g&#7903;i cho di&#7875;n &#273;&#224;n</font></strong></u></center><br />";
$lang[31]="<center> &#273;&#226;y l&#224; giai &#273;o&#7841;n cu&#7889;i c&#249;ng nh&#7853;p v&#224;o, n&#243; s&#7867; nh&#7853;p di&#7875;n &#273;&#224;n BTI c&#7911;a b&#7841;n qua SMF,<br /> n&#243; s&#7867; nh&#7853;p v&#224;o m&#7909;c l&#7909;c m&#7899;i g&#7885;i l&#224; \"My BTI import\",<br /> xin b&#7845;m <a href='".$_SERVER["PHP_SELF"]."?act=import_forum&amp;confirm=yes'> xin b&#7845;m &#7903; &#273;&#226;y </a> &#273;&#7875; ho&#224;n t&#7845;t </center>";
$lang[32]="<center><u><strong><font size='4' face='Arial'> nh&#7853;p v&#224;o xong </font></strong></u></center><br />";
$lang[33]="<center><font face=\"Arial\" size=\"2\">Xin<a target='_new' href='smf/index.php?action=login'> v&#224;o di&#7875;n &#273;&#224;n SMF m&#7899;i c&#7911;a b&#7841;n </a> s&#7917; d&#7909;ng nh&#7919;ng chi ti&#7871;t n&#417;i xu&#7845;t ph&#225;t c&#7911;a b&#7841;n  v&#224; v&#224;o <br /> ch&#7885;n <strong>trung t&#226;m h&#224;nh ch&#237;nh</strong> r&#7891;i ch&#7885;n <strong>tu b&#7893; di&#7875;n &#273;&#224;n</strong> v&#224; cho ho&#7841;t &#273;&#7897;ng <br /><strong> ki&#7871;m v&#224; s&#7917;a cho t&#7915;ng &#273;i&#7875;m sai.</strong> k&#7871; ti&#7871;p &#273;&#7871;n <strong> Ki&#7875;m k&#234; t&#7845;t c&#7843; trong di&#7875;n &#273;&#224;n <br /> v&#224; t&#7845;t c&#7843; th&#7889;ng k&#234; .</strong> l&#224;m cho s&#7921; nh&#7853;p v&#224;o v&#224; tu b&#7893; di&#7875;n &#273;&#224;n &#273;&#432;&#7907;c g&#7885;n g&#224;ng v.v....<br /><br /><strong><font color='#0000FF'> di&#7875;n &#273;&#224;n SMF c&#7911;a b&#7841;n &#273;&#227; &#273;&#432;&#7907;c h&#7907;p nh&#7845;t xong &#273;&#7875; s&#7917; d&#7909;ng!</font></strong></font></center>";
$lang[34]="<center><u><strong><font size=\"4\" face=\"Arial\" color=\"#FF0000\">SAI!</font></strong></u></center><br />\n<br />\n<center><font face=\"Arial\" size=\"3\"> B&#7841;n &#273;i&#7873;n v&#224;o m&#7853;t m&#227; kh&#244;ng &#273;&#250;ng hay b&#7841;n kh&#244;ng ph&#7843;i l&#224; ch&#7911; nh&#226;n c&#7911;a di&#7875;n &#273;&#224;n n&#224;y
!<br />\nXin bi&#7871;t r&#7857;ng &#273;&#7883;a ch&#7881; IP c&#7911;a b&#7841;n &#273;&#227; &#273;&#432;&#7907;c ghi ch&#250;.</font></center>";
$lang[35]="</body>\n</html>\n";
$lang[36]="<center>kh&#244;ng th&#7875; vi&#7871;t v&#224;o:<br /><br /><b>";
$lang[37]="</b><br /><br />Xin ch&#7855;c ch&#7855;n t&#224;i li&#7879;u n&#224;y c&#243; th&#7875; vi&#7871;t &#273;&#432;&#7907;c r&#7891;i cho ho&#7841;t &#273;&#7897;ng l&#7841;i l&#7847;n n&#7919;a.</center>";
$lang[38]="<center><br /><font color=red size=4><b>t&#7915; ch&#7889;i gia nh&#7853;p</b></font></center>";
?>