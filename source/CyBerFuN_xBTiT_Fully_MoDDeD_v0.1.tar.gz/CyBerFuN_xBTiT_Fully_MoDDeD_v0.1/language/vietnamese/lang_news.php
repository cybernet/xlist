<?php

// Translated to Vietnamese Language by VoTienSinh  & ThanhThanh for www.diemthuy.nl

$language["ERR_NO_TITLE"]="B&#7841;n ph&#7843;i ki&#7871;m cho t&#7921;a &#273;&#7873; cho tin t&#7913;c c&#7911;a b&#7841;n";
?>