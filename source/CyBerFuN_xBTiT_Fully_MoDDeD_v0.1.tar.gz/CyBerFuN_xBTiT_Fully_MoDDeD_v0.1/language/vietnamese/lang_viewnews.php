<?php

// Translated to Vietnamese Language by VoTienSinh  & ThanhThanh for www.diemthuy.nl

$language["POSTED_BY"]   = "Ng&#432;&#7901;i g&#7903;i";
$language["POSTED_DATE"] = "Ng&#224;y g&#7903;i";   
$language["TITLE"]       = "T&#7921;a &#273;&#7873;";      
$language["ADD"]         = "Th&#234;m v&#224;o";   

?>