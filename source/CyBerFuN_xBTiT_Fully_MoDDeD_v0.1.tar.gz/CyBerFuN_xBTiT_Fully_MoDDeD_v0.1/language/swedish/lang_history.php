<?php
$language['PEER_PROGRESS'] = 'Framsteg';
$language['PEER_COUNTRY'] = 'Land';
$language['PEER_PORT'] = 'Port';
$language['PEER_STATUS'] = 'Status';
$language['PEER_CLIENT'] = 'Klient';
$language['NO_HISTORY'] = 'Ingen historia att visa';
?>