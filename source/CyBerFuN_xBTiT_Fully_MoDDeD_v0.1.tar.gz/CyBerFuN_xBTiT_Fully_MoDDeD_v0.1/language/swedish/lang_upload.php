<?php
$language['NOT_SHA'] ='SHA1 funktion inte till g�nglig. Du beh�ver PHP 4.3.0 eller b�ttre.';
$language['NOT_AUTHORIZED_UPLOAD'] = 'Du har inte beh�righet att ladda upp!';
$language['FILE_UPLOAD_ERROR_1'] = 'Kan inte l�sa uppladdad fil';
$language['FILE_UPLOAD_ERROR_3'] = 'Filens storlek �r 0';
$language['FACOLTATIVE'] = 'optional';
$language['FILE_UPLOAD_ERROR_2'] = 'Filuppladdningsfel';
$language['ERR_PARSER'] = 'Det ser ut som det finns ett fel i din torrent. Parsern accepterade det inte.';
$language['WRITE_CATEGORY'] = 'Du m�ste v�lja kategori';
$language['DOWNLOAD'] = 'Ladda Hem';
$language['MSG_UP_SUCCESS'] = 'Uppladdningen lyckades! Torrenten finns nu p� trackern.';
$language['MSG_DOWNLOAD_PID'] = 'PID systemet �r aktiverat, ladda hem torrenten med dit PID nummer';
$language['EMPTY_DESCRIPTION'] = 'Du m�ste fylla i Beskrivningen!';
$language['EMPTY_ANNOUNCE'] = 'Announce �r tomt';
$language['FILE_UPLOAD_ERROR_1'] = 'Kan inte l�sa uppladdad fil';
$language['FILE_UPLOAD_ERROR_2'] = 'Filen som �r uppladdad har storleken 0 KiB';
$language['FILE_UPLOAD_ERROR_3'] = 'Filen som �r uppladdad har storleken 0 KiB';
$language['NO_SHA_NO_UP'] = 'Uppladdning inte tillg�ngligt - ingen SHA1 kryptering.';
$language['NOT_SHA'] = 'SHA1 funktion inte till g�nglig. Du beh�ver PHP 4.3.0 eller b�ttre.';
$language['ERR_PARSER'] = 'Det ser ut som det finns ett fel i din torrent. Parsern accepterade den inte';
$language['WRITE_CATEGORY'] = 'Du m�ste v�lja kategori';
$language['ERR_HASH'] = 'Info hash m�ste ha exakt 40 hex bytes.';
$language['ERR_EXTERNAL_NOT_ALLOWED'] = 'Externa torrents �r inte till�tna';
$language['ERR_MOVING_TORR'] = 'fel n�r torrent flyttas...';
$language['ERR_ALREADY_EXIST'] = 'Denna torrent kanse redan finns i v�rat data system.';
$language['MSG_DOWNLOAD_PID'] = 'PID systemet �r aktiverat, ladda hem torrenten med dit PID nummer';
$language['MSG_UP_SUCCESS'] = 'Uppladdning lyckades! Torrenten har blivit uppladdad.';
?>