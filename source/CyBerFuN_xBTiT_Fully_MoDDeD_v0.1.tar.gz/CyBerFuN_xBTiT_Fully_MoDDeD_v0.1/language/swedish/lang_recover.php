<?php
$language['charset']='ISO-8859-1';
$language['ERR_NO_EMAIL'] = 'Du m�ste ange en e-post adress';
$language['ERR_INV_EMAIL'] = 'Du m�ste ange en riktig e-post adress';
$language['ERR_NO_CAPTCHA'] = 'Du m�ste skriva in s�kerhetskoden';
$language['IMAGE_CODE'] = 'S�kerhetskod';
$language['SECURITY_CODE'] = 'Svar p� fr�gan';
$language['RECOVER_EMAIL_1'] = '\nN�gon, F�rhoppningsvis �r det du,som har fr�gat f�r l�senordet f�r Kontot anslutet med denna email address (%s) kommer att nollst�llas.\n\nf�r fr�gan kom fr�n %s.\n\nifall du inte gjorde det sn�lla strunta i detta medelande. Sn�lla svara inte p� detta mail.\n\nvill du bekr�fta f�r fr�gan s� f�lj denna l�nk:\n\n%s\n\nefter du har gjort detta, kommer ditt l�snord �ndras och skickas till dig.\n--\n%s';
$language['RECOVER_EMAIL_2'] = '\nEfter per Din f�rfr�gan har vi genererat ett nytt l�senord f�r ditt konto.\n\nH�r �r informationen  f�r detta konto:\n\n    anv�ndar namn: %s\n    l�snord: %s\n\ndu kanske ska logga in p� %s\n\n--\n%s';
?>