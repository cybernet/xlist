<?php
$language['charset']='ISO-8859-1';
$language['FIND_USER'] = 'Hitta anv�ndare';
$language['USER_LEVEL'] = 'Klass';
$language['ALL'] = 'Alla';
$language['SEARCH'] = 'S�k';
$language['USER_NAME'] = 'Anv�ndarnamn';
$language['USER_LEVEL'] = 'Anv�ndarens Klass';
$language['USER_JOINED'] = 'Blev medlem';
$language['USER_LASTACCESS'] = 'Senast inloggad';
$language['USER_COUNTRY'] = 'Land';
$language['RATIO'] = 'Ratio';
$language['USERS_PM'] = 'PM';
$language['EDIT'] = 'Editera';
$language['DELETE'] = 'Radera';
$language['NO_USERS_FOUND'] = 'Inga anv�ndare hittades!';
$language['UNKNOWN'] = 'Ok�nd';
?>