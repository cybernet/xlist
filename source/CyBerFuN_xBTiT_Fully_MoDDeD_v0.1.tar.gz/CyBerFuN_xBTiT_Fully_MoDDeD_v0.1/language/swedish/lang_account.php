<?php
$language['charset']='ISO-8859-1';
$language['ACCOUNT_CREATED'] = 'Konto skapat';
$language['USER_NAME'] = 'Anv�ndare';
$language['USER_PWD_AGAIN'] = 'Upprepa L�senord';
$language['USER_PWD'] = 'L�senord';
$language['USER_STYLE'] = 'Stil';
$language['USER_LANGUE'] = 'Spr�k';
$language['IMAGE_CODE'] = 'S�kerhetskod';
$language['INSERT_USERNAME'] = 'Du m�ste ange ett anv�ndarnamn!';
$language['INSERT_PASSWORD'] = 'Du m�ste ange ett l�senord!';
$language['DIF_PASSWORDS'] = 'L�snorden matchar inte varandra!';
$language['ERR_NO_EMAIL'] = 'Du m�ste ange en riktig E-post adress';
$language['USER_EMAIL_AGAIN'] = 'Upprepa E-postl adress';
$language['ERR_NO_EMAIL_AGAIN'] = 'Upprepa E-post adressen';
$language['DIF_EMAIL'] = 'E-post adresserna matchar inte varandra!';
$language['SECURITY_CODE'] = 'Svar p� fr�gan';
# Password strength
$language['WEEK'] = 'Svagt';
$language['MEDIUM'] = 'Medium';
$language['SAFE'] = 'S�kert L�senord';
$language['STRONG'] = 'Starkt L�senord';

?>