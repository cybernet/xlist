<?php
$language['INSERT_USERNAME'] = 'Du m�ste ange ett anv�ndarnamn!';
$language['INSERT_PASSWORD'] = 'Du m�ste ange ett l�senord!';
?>