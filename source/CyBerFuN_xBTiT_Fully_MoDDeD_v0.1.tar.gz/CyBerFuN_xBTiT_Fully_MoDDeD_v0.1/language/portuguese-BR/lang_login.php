<?php
$language["INSERT_USERNAME"]="Você deve inserir um nome de usuário!";
$language["INSERT_PASSWORD"]="Você deve inserir uma senha!";
?>
