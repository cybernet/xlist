<?php
$language["NOT_SHA"]="La fonction SHA1 n'est pas disponible. Vous avez besoin de PHP 4.3.0 ou sup�rieur.";
$language["NOT_AUTHORIZED_UPLOAD"]="Vous n'�tes pas autoris� � envoyer !";
$language["FILE_UPLOAD_ERROR_1"]="Impossible de lire le fichier envoy�";
$language["FILE_UPLOAD_ERROR_2"]="Erreur d'upload du fichier";
$language["FILE_UPLOAD_ERROR_3"]="Le fichier � une taille de 0";
$language["FACOLTATIVE"]="optionnel";
$language["FILE_UPLOAD_ERROR_2"]="Erreur d'envoi du fichier";
$language["ERR_PARSER"]="Il semble y avoir une erreur dans votre torrent. Le parser ne l'accepte pas.";
$language["WRITE_CATEGORY"]="Vous devez sp�cifier une cat�gorie...";
$language["DOWNLOAD"]="T�l�charg�";
$language["MSG_UP_SUCCESS"]="Envoi r�ussi ! Le torrent � bien �t� ajout�.";
$language["MSG_DOWNLOAD_PID"]="Le PID est activ�, merci de vous servir de votre PID";
$language["EMPTY_DESCRIPTION"]="Vous devez entrer une description !";
$language["EMPTY_ANNOUNCE"]="L'annonce est vide !";
$language["NO_SHA_NO_UP"]="Fichier de t�l�chargement non disponible - pas de fonction SHA1.";
$language["ERR_HASH"]="L'info hash DOIT �tre exactement de 40 hex octets.";
$language["ERR_EXTERNAL_NOT_ALLOWED"]="Les torrents externes ne sont pas accept�s";
$language["ERR_MOVING_TORR"]=" Erreur de d�placement du torrent...";
$language["ERR_ALREADY_EXIST"]="Ce torrent existent peut-�tre d�ja.";
?>