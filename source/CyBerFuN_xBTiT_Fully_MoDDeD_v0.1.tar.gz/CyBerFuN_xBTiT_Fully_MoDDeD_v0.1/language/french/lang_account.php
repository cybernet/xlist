<?php
$language["ACCOUNT_CREATED"]="Compte cr��";
$language["USER_NAME"]="Utilisateur";
$language["USER_PWD_AGAIN"]="Confirmez le mot de passe";
$language["USER_PWD"]="Mot de passe";
$language["USER_STYLE"]="Style";
$language["USER_LANGUE"]="Language";
$language["IMAGE_CODE"]="Code image";
$language["INSERT_USERNAME"]="Vous devez saisir un nom d'utilisateur !";
$language["INSERT_PASSWORD"]="Vous devez saisir un mot de passe !";
$language["DIF_PASSWORDS"]="Les mots de passe ne correspondent pas !";
$language["ERR_NO_EMAIL"]="Vous devez saisir un courriel valide !";
$language["USER_EMAIL_AGAIN"]="Confirmez le courriel";
$language["ERR_NO_EMAIL_AGAIN"]="Confirmez le courriel";
$language["DIF_EMAIL"]="Les courriels ne correspondent pas !";
$language["SECURITY_CODE"]="R�pondez � la question";
# Password strength
$language["WEEK"]="Faible";
$language["MEDIUM"]="Moyen";
$language["SAFE"]="Securis�";
$language["STRONG"]="Fort";

?>