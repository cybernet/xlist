<?php
$language["BLOCK_USER"]="Information sur l'utilisateur";
$language["BLOCK_INFO"]="Information du tracker";
$language["BLOCK_MENU"]="Menu";
$language["BLOCK_CLOCK"]="Horloge";
$language["BLOCK_FORUM"]="Forum";
$language["BLOCK_LASTMEMBER"]="Dernier membre";
$language["BLOCK_ONLINE"]="En ligne";
$language["BLOCK_ONTODAY"]="Aujourd'hui";
$language["BLOCK_SHOUTBOX"]="Clavardage";
$language["BLOCK_TOPTORRENTS"]="Top des torrents";
$language["BLOCK_LASTTORRENTS"]="Dernier envoi";
$language["BLOCK_NEWS"]="Derni�res Nouvelles";
$language["BLOCK_SERVERLOAD"]="Charge du serveur";
$language["BLOCK_POLL"]="Sondage";
$language["BLOCK_SEEDWANTED"]="Besoin de seeders";
$language["BLOCK_PAYPAL"]="Supportez nous";
$language["BLOCK_MAINTRACKERTOOLBAR"]="Barre d'outils du tracker";
$language["BLOCK_MAINUSERTOOLBAR"]="Barre d'outils";
$language["WELCOME_LASTUSER"]=" Bienvenue sur notre tracker ";
$language["BLOCK_MINCLASSVIEW"]="Rang minimum qui peut �tre vu";
$language["BLOCK_MAXCLASSVIEW"]="Rang maximum qui peut �tre vu";
?>