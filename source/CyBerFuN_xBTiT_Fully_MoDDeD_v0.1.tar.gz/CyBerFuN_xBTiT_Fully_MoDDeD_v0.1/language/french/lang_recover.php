<?php
$language["ERR_NO_EMAIL"]="Vous devez fournir un courriel";
$language["ERR_INV_EMAIL"]="Vous devez entrer un courriel valide";
$language["ERR_NO_CAPTCHA"]="Vous devez entrer le code image";
$language["IMAGE_CODE"]="Code image";
$language["SECURITY_CODE"]="R�pondez � la question";
�$language["RECOVER_EMAIL_1"]="\nQuelqu'un, normalement, vous a demand� que le mot de passe du compte associ� � ce courriel (% s) soit remis � z�ro.\n\nLa demande a pour origine %s.\n\nSi vous n'en avez pas fait la demande, ignorez ce courriel. Merci de ne pas r�pondre.\n\nVous devez confirmer cette requ�te, merci de cliquer sur ce lien :\n\n%s\n\nApr�s avoir fait cela, votre mot de passe sera remis � z�ro et vous sera envoy� par courriel.\n--\n%s";
$language["RECOVER_EMAIL_2"]="\nSuite � votre demande, nous avons g�n�r� un nouveau mot de passe pour votre compte.\n\nVoici les renseignements que nous avons maintenant enregistr� pour ce compte :\n\n    Nom d'utilisateur : %s\n    Mot de passe : %s\n\nIdentifiez-vous ici %s\n\n--\n%s";
?>