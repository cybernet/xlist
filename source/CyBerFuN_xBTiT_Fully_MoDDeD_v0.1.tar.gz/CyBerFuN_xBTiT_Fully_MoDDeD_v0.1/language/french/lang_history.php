<?php
$language["PEER_PROGRESS"]="Progr�s";
$language["PEER_COUNTRY"]="Pays";
$language["PEER_PORT"]="Port";
$language["PEER_STATUS"]="Statut";
$language["PEER_CLIENT"]="Client";
$language["NO_HISTORY"]="Aucun historique � afficher";
?>