﻿<?php
// VIEWNEWS.PHP LANGUAGE FILE
$language['POSTED_BY']='Adăugată de';
$language['POSTED_DATE']='Data';
$language['TITLE']='Titlu';
$language['ADD']='Adaugă';
?>
