﻿<?php
$language['NOT_SHA']='Funcţia SHA1 nu este disponibilă. Ai nevoie de PHP versiunea 4.3.0 sau mai mare.';
$language['NOT_AUTHORIZED_UPLOAD']='Nu eşti autorizat să faci Upload!';
$language['FILE_UPLOAD_ERROR_1']='Fiţierul urcat nu poate fi citit';
$language['FILE_UPLOAD_ERROR_3']='Dimensiunea fişierului este zero';
$language['FACOLTATIVE']='opţional';
$language['FILE_UPLOAD_ERROR_2']='Eroare Upload Fişier';
$language['ERR_PARSER']='Se pare că există o eroare în fişierul torrent. Sistemul nu l-a acceptat.';
$language['WRITE_CATEGORY']='Trebuie să specifici o Categorie pentru torrent-ul tau...';
$language['DOWNLOAD']='Download';
$language['MSG_UP_SUCCESS']='Upload-ul s-a realizat cu succes! Torrent-ul a fost adăugat.';
$language['MSG_DOWNLOAD_PID']='Sistem PID activ, descarcă-ţi torrent-ul cu PID';
$language['EMPTY_DESCRIPTION']='Trebuie să adaugi o scurtă descriere!';
$language['EMPTY_ANNOUNCE']='Link-ul de Anunţare este gol';
$language['NO_SHA_NO_UP']='Funcţia de Upload nu este disponibilă - lipseşte funţia SHA1.';
$language['ERR_HASH']='Hash-ul TREBUIE să fie exact de 40 biţi hex.';
$language['ERR_EXTERNAL_NOT_ALLOWED']='Torrent-ele Externe nu sunt permise';
$language['ERR_MOVING_TORR']='Eroare mutare torrent...';
$language['ERR_ALREADY_EXIST']='Acest torrent s-ar putea să existe deja in Baza de Date.';
?>