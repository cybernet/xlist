<?php
$language["PEER_PROGRESS"]="Haladás";
$language["PEER_COUNTRY"]="Ország";
$language["PEER_PORT"]="Port";
$language["PEER_STATUS"]="Státusz";
$language["PEER_CLIENT"]="Kliens";
$language["NO_PEERS"]="Nincsenek peerek";
?>