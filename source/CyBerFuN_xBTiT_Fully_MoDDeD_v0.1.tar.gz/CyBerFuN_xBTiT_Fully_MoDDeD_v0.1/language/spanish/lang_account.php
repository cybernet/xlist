<?php
$language['ACCOUNT_CREATED']='Cuenta creada';
$language['USER_NAME']='Usuario';
$language['USER_PWD_AGAIN']='Repetir contrase�a';
$language['USER_PWD']='Contrase�a';
$language['USER_STYLE']='Estilo';
$language['USER_LANGUE']='Idioma';
$language['IMAGE_CODE']='C�digo de la imagen';
$language['INSERT_USERNAME']='Debes insertar un nombre de usuario!';
$language['INSERT_PASSWORD']='Debes insertar una contrase�a!';
$language['DIF_PASSWORDS']='Las contrase�as no coinciden!';
$language['ERR_NO_EMAIL']='Debes introducir una direcci�n de email v�lida.';
$language['USER_EMAIL_AGAIN']='Repetir email';
$language['ERR_NO_EMAIL_AGAIN']='Repetir email';
$language['DIF_EMAIL']='Los emails no coinciden!';
$language['SECURITY_CODE']='C�digo de Seguridad';
# Password strength
$language['WEEK']='D�bil';
$language['MEDIUM']='Media';
$language['SAFE']='Segura';
$language['STRONG']='�ptima';

?>