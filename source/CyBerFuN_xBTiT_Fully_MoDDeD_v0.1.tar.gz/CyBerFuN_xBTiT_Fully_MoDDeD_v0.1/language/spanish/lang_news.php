<?php
$language['ERR_NO_TITLE']='Debes proporcionar un T�tulo para tu noticia';
?>