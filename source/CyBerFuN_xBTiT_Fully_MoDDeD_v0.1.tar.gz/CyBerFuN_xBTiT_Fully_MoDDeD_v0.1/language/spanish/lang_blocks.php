<?php
$language['BLOCK_USER']='Info del Usuario';
$language['BLOCK_INFO']='Info del Tracker';
$language['BLOCK_MENU']='Menu Principal';
$language['BLOCK_CLOCK']='Reloj';
$language['BLOCK_FORUM']='Foro';
$language['BLOCK_LASTMEMBER']='Ultimo Miembro';
$language['BLOCK_ONLINE']='En Linea';
$language['BLOCK_ONTODAY']='En L�nea Hoy';
$language['BLOCK_SHOUTBOX']='Chat';
$language['BLOCK_TOPTORRENTS']='Top Torrents';
$language['BLOCK_LASTTORRENTS']='�ltimos Torrents';
$language['BLOCK_NEWS']='�ltimas Noticias';
$language['BLOCK_SERVERLOAD']='Carga del Servidor';
$language['BLOCK_POLL']='Encuesta';
$language['BLOCK_SEEDWANTED']='Torrents que necesitan Semillas';
$language['BLOCK_PAYPAL']='Ayudanos con';
$language['BLOCK_MAINTRACKERTOOLBAR']='Barra de herramientas principal del Tracker';
$language['BLOCK_MAINUSERTOOLBAR']='Barra de herramientas principal del usuario';
$language['WELCOME_LASTUSER']=' Bienvenido a nuestro Tracker ';
$language['BLOCK_MINCLASSVIEW']='Rango minimo que puedes ver';
$language['BLOCK_MAXCLASSVIEW']='Rango m�ximo que puedes ver';
?>