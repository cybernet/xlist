<?php
$language['NOT_SHA']='La funci�n SHA1 no est� disponible. Necesitas PHP 4.3.0 o superior.';
$language['NOT_AUTHORIZED_UPLOAD']='�No est�s autorizado a subir!';
$language['FILE_UPLOAD_ERROR_1']='No se puede leer el archivo cargado';
$language['FILE_UPLOAD_ERROR_3']='El archivo es de tama�o cero';
$language['FACOLTATIVE']='opcional';
$language['FILE_UPLOAD_ERROR_2']='Error al cargar el archivo';
$language['ERR_PARSER']='Parece que hay un error en su torrent. El parser no la acept�.';
$language['WRITE_CATEGORY']='Debes especificar la categor�a del torrent...';
$language['DOWNLOAD']='Descargar';
$language['MSG_UP_SUCCESS']='�Carga con �xito! El torrent se ha a�adido.';
$language['MSG_DOWNLOAD_PID']='El sistema activo PID obtiene el torrent con tu PID';
$language['EMPTY_DESCRIPTION']='�Debes introducir una descripci�n!';
$language['EMPTY_ANNOUNCE']='El anuncio est� vac�o';
$language['FILE_UPLOAD_ERROR_1']='No se puede leer el archivo cargado';
$language['FILE_UPLOAD_ERROR_2']='Error al cargar el archivo';
$language['FILE_UPLOAD_ERROR_3']='El archivo es de tama�o cero';
$language['NO_SHA_NO_UP']='La carga de archivos no est� disponible - no hay funci�n SHA1.';
$language['NOT_SHA']='La funci�n SHA1 no est� disponible. Necesitas PHP 4.3.0 o superior.';
$language['ERR_PARSER']='Parece que hay un error en su torrent. El parser no la acept�.';
$language['WRITE_CATEGORY']='Debes especificar la categor�a del torrent...';
$language['ERR_HASH']='Info de hash DEBE ser exactamente de 40 hex bytes.';
$language['ERR_EXTERNAL_NOT_ALLOWED']='Torrents externos no permitidos';
$language['ERR_MOVING_TORR']='Error moviendo torrent...';
$language['ERR_ALREADY_EXIST']='Este torrent ya existe en nuestra base de datos.';
$language['MSG_DOWNLOAD_PID']='El sistema activo PID obtiene el torrent con tu PID';
$language['MSG_UP_SUCCESS']='�Carga con �xito! El torrent se ha a�adido.';

?>