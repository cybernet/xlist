Translation By b0uncer(http://vip-yokerho.no-ip.org)VIP-Lounge

i Donated this translation to Lupin and the Xbtit source for great help and support.
Keep it rocking!

-b0uncer(on xbtit private=nick Elite)