<?php
$language["INSERT_USERNAME"]="Sy&ouml;t&auml; k&auml;ytt&auml;j&auml;nimi!";
$language["INSERT_PASSWORD"]="Sy&ouml;t&auml; salasana!";
?>