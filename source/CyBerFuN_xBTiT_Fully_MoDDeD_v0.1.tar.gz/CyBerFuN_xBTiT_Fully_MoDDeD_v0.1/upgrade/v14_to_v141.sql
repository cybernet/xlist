ALTER TABLE `users` ADD `temp_email` VARCHAR( 50 ) NOT NULL ;
